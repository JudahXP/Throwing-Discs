Judah's Throwing Discs 1.4.1 — NeoForge

Install only the JAR matching your Minecraft version. Requires the NeoForge version listed in validation.json or a compatible newer release. Do not install together with Fabric or Forge editions.

Includes copper-first creative ordering, mod icons, Harvest and the existing disc behavior. Minecraft 1.20 has no NeoForge release.

Validation: compilation and JAR inspection only. Gameplay not tested.
