Judah's Throwing Discs 1.4.1 — Forge

Install only the JAR matching your Minecraft version, with Forge. Do not install the Fabric edition alongside it.
Includes all five disc tiers and the existing 1.4.1 behavior: smooth direct return, return-only phasing within eight blocks, unlimited bounce count, Harvest, reusable dispenser throws, and no Ricochet enchantment.

Minecraft 1.20.5 and 1.21.2 are omitted because Forge does not publish releases for them.
Validation was deliberately limited to compilation and JAR inspection. No game-test suites or gameplay tests were run for these Forge ports.
